#!/bin/bash

# 1. تحديد النموذج الذي تملكه
SELECTED_MODEL="translategemma:12b"

# 2. الحصول على النص المظلل
if [ "$XDG_SESSION_TYPE" = "wayland" ]; then
    TEXT=$(wl-paste --primary)
    if [ -z "$TEXT" ]; then TEXT=$(wl-paste); fi
else
    TEXT=$(xclip -o)
fi

# التحقق من وجود نص
if [ -z "$TEXT" ]; then
    zenity --error --text="الرجاء تظليل نص أولاً!" --title="خطأ"
    exit 1
fi

# 3. إرسال النص إلى Ollama بطريقة آمنة (عبر تجميع الـ JSON بواسطة jq)
# هذه الطريقة تمنع حدوث أخطاء بسبب علامات التنصيص في النص الأصلي
JSON_DATA=$(jq -n --arg model "$SELECTED_MODEL" --arg prompt "Translate the following text to Arabic. Output only the translation: $TEXT" \
    '{model: $model, prompt: $prompt, stream: false}')

RESPONSE=$(curl -s -X POST http://localhost:11434/api/generate -d "$JSON_DATA" | jq -r '.response' 2>/dev/null)

# 4. عرض النتيجة
if [ -z "$RESPONSE" ] || [ "$RESPONSE" == "null" ]; then
    zenity --error --text="تعذر الحصول على رد من الموديل ($SELECTED_MODEL). تأكد أن Ollama يعمل." --title="خطأ في الاتصال"
else
    echo "$RESPONSE" | zenity --text-info --title="الترجمة بواسطة $SELECTED_MODEL" --width=600 --height=400 --font="Ubuntu 14"
fi
