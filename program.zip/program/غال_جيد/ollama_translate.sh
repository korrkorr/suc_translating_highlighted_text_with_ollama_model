#!/bin/bash

# 1. الإعدادات
MODEL="translategemma:12b"

# 2. جلب النص المظلل (دعم كامل لـ Wayland و X11)
if [ "$XDG_SESSION_TYPE" = "wayland" ]; then
    TEXT=$(wl-paste --primary 2>/dev/null || wl-paste)
else
    TEXT=$(xclip -o)
fi

# إذا كان النص فارغاً
if [ -z "$TEXT" ]; then
    notify-send "Ollama" "لم يتم تظليل أي نص!"
    exit 1
fi

# 3. بناء الطلب بصيغة JSON صحيحة 100% باستخدام jq
# هذه الطريقة تعالج علامات التنصيص والرموز الغريبة تلقائياً
PAYLOAD=$(jq -n \
    --arg md "$MODEL" \
    --arg pr "Translate the following text to Arabic. Output only the translation. \n\nText: $TEXT" \
    '{model: $md, prompt: $pr, stream: false, options: {temperature: 0.2}}')

# 4. إرسال الطلب وحفظ الرد الكامل في متغير
RESPONSE_RAW=$(curl -s -X POST http://127.0.0.1:11434/api/generate -d "$PAYLOAD")

# 5. استخراج الترجمة أو الخطأ
TRANSLATION=$(echo "$RESPONSE_RAW" | jq -r '.response // empty')
ERROR_MSG=$(echo "$RESPONSE_RAW" | jq -r '.error // empty')

# 6. العرض النهائي
if [ -n "$TRANSLATION" ]; then
    # عرض الترجمة في نافذة
    echo -e "الترجمة (بواسطة $MODEL):\n\n$TRANSLATION" | zenity --text-info --title="Ollama Translate" --width=700 --height=500 --font="Ubuntu 14"
elif [ -n "$ERROR_MSG" ]; then
    zenity --error --text="خطأ من Ollama: $ERROR_MSG"
else
    # إذا كان الرد فارغاً تماماً، نعرض الرد الخام للتشخيص
    zenity --error --text="رد غير معروف. تأكد أن الموديل $MODEL محمل.\n\nالرد الخام: $RESPONSE_RAW"
fi
