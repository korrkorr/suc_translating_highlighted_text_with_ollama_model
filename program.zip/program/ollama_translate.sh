#!/bin/bash

# 1. تحديد النموذج الافتراضي (يمكنك تغييره هنا)
# إذا أردت استخدامه مباشرة دون سؤال، اجعل القيمة ثابتة
DEFAULT_MODEL="translategemma:12b"

# 2. الحصول على النص المظلل
if [ "$XDG_SESSION_TYPE" = "wayland" ]; then
    TEXT=$(wl-paste --primary)
    if [ -z "$TEXT" ]; then TEXT=$(wl-paste); fi
else
    TEXT=$(xclip -o)
fi

if [ -z "$TEXT" ]; then
    zenity --error --text="الرجاء تظليل نص أولاً!" --title="خطأ"
    exit 1
fi

# 3. جلب قائمة الموديلات المثبتة في Ollama (اختياري: إذا أردت اختيار موديل مختلف كل مرة)
# إذا كنت تريد استخدام الموديل الثابت دائماً، ابقِ السطر التالي معلقاً (#)
SELECTED_MODEL=$(ollama list | awk '{if(NR>1) print $1}' | zenity --list --title="اختر نموذج الترجمة" --column="الموديلات المتوفرة" --default-value="$DEFAULT_MODEL")

# إذا لم يتم اختيار موديل (إغلاق النافذة)، استخدم الافتراضي
if [ -z "$SELECTED_MODEL" ]; then
    SELECTED_MODEL=$DEFAULT_MODEL
fi

# 4. إرسال النص إلى Ollama
# ملاحظة: تم تحسين البرومبت ليتناسب مع نماذج الترجمة المتخصصة
RESPONSE=$(curl -s http://localhost:11434/api/generate -d '{
  "model": "'"$SELECTED_MODEL"'",
  "prompt": "Translate the following text to Arabic. Return only the translation:\n\n'"$TEXT"'",
  "stream": false
}' | jq -r '.response')

# 5. عرض النتيجة
if [ -z "$RESPONSE" ] || [ "$RESPONSE" == "null" ]; then
    zenity --error --text="فشل الاتصال بـ Ollama أو النموذج غير موجود."
else
    echo "$RESPONSE" | zenity --text-info --title="الترجمة بواسطة $SELECTED_MODEL" --width=600 --height=400 --font="Ubuntu 14" --editable
fi
